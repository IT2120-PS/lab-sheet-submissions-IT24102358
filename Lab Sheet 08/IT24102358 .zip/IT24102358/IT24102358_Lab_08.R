setwd("C:/Users/USER/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24102358")
nicotine <- read.table("Data - Lab 8.txt", header=TRUE)
laptops <- read.table("Exercise - LaptopsWeights.txt", header=TRUE)

# --- Part 1: Nicotine dataset
pop_mean_nicotine <- mean(nicotine$Nicotine)
pop_var_nicotine <- var(nicotine$Nicotine) * (length(nicotine$Nicotine)-1) / length(nicotine$Nicotine)

cat("Population Mean (Nicotine):", pop_mean_nicotine, "\n")
cat("Population Variance (Nicotine):", pop_var_nicotine, "\n")

set.seed(123)
sample_means <- c()
sample_vars <- c()
for (i in 1:30) {
  s <- sample(nicotine$Nicotine, size=5, replace=TRUE)
  sample_means[i] <- mean(s)
  sample_vars[i] <- var(s)
}


mean_sample_means <- mean(sample_means)
var_sample_means <- var(sample_means) * (length(sample_means)-1) / length(sample_means)

cat("Mean of Sample Means (Nicotine):", mean_sample_means, "\n")
cat("Variance of Sample Means (Nicotine):", var_sample_means, "\n")

# --- Part 2: Laptop weights dataset

pop_mean_laptops <- mean(laptops$Weight)
pop_sd_laptops <- sd(laptops$Weight) * sqrt((length(laptops$Weight)-1)/length(laptops$Weight))

cat("Population Mean (Laptops):", pop_mean_laptops, "\n")
cat("Population SD (Laptops):", pop_sd_laptops, "\n")

set.seed(123)
sample_means_laptops <- c()
sample_sds_laptops <- c()
for (i in 1:25) {
  s <- sample(laptops$Weight, size=6, replace=TRUE)
  sample_means_laptops[i] <- mean(s)
  sample_sds_laptops[i] <- sd(s)
}


mean_sample_means_laptops <- mean(sample_means_laptops)
sd_sample_means_laptops <- sd(sample_means_laptops) * sqrt((length(sample_means_laptops)-1)/length(sample_means_laptops))

cat("Mean of Sample Means (Laptops):", mean_sample_means_laptops, "\n")
cat("SD of Sample Means (Laptops):", sd_sample_means_laptops, "\n")
