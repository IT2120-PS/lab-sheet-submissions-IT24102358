# IT2120 – Lab 06.

setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102358")

# -------------------------
# Exercise 1:
n <- 50
p <- 0.85

# i)
cat("Exercise1.i) X ~ Binomial(n=50, p=0.85)\n")

# ii)
prob_ge_47 <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
cat("Exercise1.ii) P(X >= 47) =", prob_ge_47, "\n\n")


# Exercise 2:

lambda <- 12

# i) 
cat("Exercise2.i) X = number of calls received in one hour\n")

# ii) 
cat("Exercise2.ii) X ~ Poisson(lambda = 12)\n")

# iii) 
prob_eq_15 <- dpois(15, lambda)
cat("Exercise2.iii) P(X = 15) =", prob_eq_15, "\n")