setwd("C:/Users/USER/OneDrive - Sri Lanka Institute of Information Technology/Desktop/IT24102358")

data <- read.table("Data.txt", header = TRUE, sep = ",")
fix(data)
attach(data)

names(data) <- c("X1", "X2")
attach(data)

hist(X2, main = "Histogram for Number of Shareholders")

histogram <- hist(X2, main = "Histogram for Number of Shareholders",
                  breaks = seq(130, 270, length = 8), right = FALSE)

breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()
for(i in 1:(length(breaks) - 1)){
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

cbind(classes = classes, frequency = freq)

plot(mids, freq, type = "l",
     main = "Frequency Polygon for Shareholders",
     xlab = "Shareholders", ylab = "Frequency",
     ylim = c(0, max(freq)))

cum.freq <- cumsum(freq)

new <- c()
for(i in 1:length(breaks)){
  if(i == 1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new, type = "o",
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders", ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

cbind(Upper = breaks, CumFreq = new)

# -------------------------------------------------
# Exercise
# -------------------------------------------------

delivery <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(delivery)

times <- delivery$Delivery_Time_.minutes.

hist(times,
     breaks = seq(20, 70, length.out = 10),
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)", col = "orange")

hist_data <- hist(times, breaks = seq(20, 70, length.out = 10),
                  plot = FALSE, right = FALSE)

plot(hist_data$mids, hist_data$counts, type = "o", col = "blue",
     main = "Frequency Polygon of Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Frequency")

cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq, type = "o", col = "darkgreen",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency")
