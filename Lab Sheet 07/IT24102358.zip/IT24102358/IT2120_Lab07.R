

setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102358")  


# Question 1:


# i. 
punif(10, min = 0, max = 30) - punif(0, min = 0, max = 30)

# ii.
1 - punif(20, min = 0, max = 30)



# Question 2:

lambda <- 1/2

# i.
pexp(3, rate = lambda)

# ii.
1 - pexp(4, rate = lambda)

# iii.
pexp(4, rate = lambda) - pexp(2, rate = lambda)



# Question 3:

mu <- 36.8
sigma <- 0.4

# i.
1 - pnorm(37.9, mean = mu, sd = sigma)

# ii.
pnorm(36.9, mean = mu, sd = sigma) - pnorm(36.4, mean = mu, sd = sigma)

# iii.
qnorm(0.012, mean = mu, sd = sigma)

# iv.
qnorm(0.99, mean = mu, sd = sigma)



# Exercises


# 1.
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

# 2.
pexp(2, rate = 1/3)

# 3.
mean_iq <- 100
sd_iq <- 15

# i.
1 - pnorm(130, mean = mean_iq, sd = sd_iq)

# ii.
qnorm(0.95, mean = mean_iq, sd = sd_iq)
